sudo sysctl net.ipv4.conf.all.forwarding=0
sudo chmod 777 /home/ubuntu/logging
echo -n "Mail: " | cat - /home/ubuntu/.local/.email > /home/ubuntu/mail.txt
# Failsafe for Python 2/3 compatibility in Student.py on all student machines
sed -i 's/0o666/0666/g' /home/ubuntu/.local/bin/Student.py 2>/dev/null || true
sed -i 's/0o666/0666/g' /root/.local/bin/Student.py 2>/dev/null || true
mkdir -p /home/ubuntu/.local/bin /root/.local/bin
if [ -f /home/ubuntu/.local/bin/Student.py ]; then
    sed -i 's/0o666/0666/g' /home/ubuntu/.local/bin/Student.py 2>/dev/null || true
    chmod 755 /home/ubuntu/.local/bin/Student.py 2>/dev/null || true
fi
