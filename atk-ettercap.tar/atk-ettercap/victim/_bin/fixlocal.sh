#!/bin/bash
#
#  This script will be run after parameterization has completed, e.g., 
#  use this to compile source code that has been parameterized.
#  The container user password will be passed as the first argument,
#  (the user ID is the second parameter)
#  If this script is to use sudo and the sudoers for the lab
#  does not permit nopassword, then use:
#  echo $1 | sudo -S the-command
#
#  If you issue commands herein to start services, and those services
#  have unit files prescribing their being started after the
#  waitparam.service, then first create the flag directory that
#  waitparam sleeps on:
#
#   PERMLOCKDIR=/var/labtainer/did_param
#   echo $1 | sudo -S mkdir -p "$PERMLOCKDIR"
# Failsafe for Python 2/3 compatibility in Student.py on all student machines
sed -i 's/0o666/0666/g' /home/ubuntu/.local/bin/Student.py 2>/dev/null || true
sed -i 's/0o666/0666/g' /root/.local/bin/Student.py 2>/dev/null || true
mkdir -p /home/ubuntu/.local/bin /root/.local/bin
if [ -f /home/ubuntu/.local/bin/Student.py ]; then
    sed -i 's/0o666/0666/g' /home/ubuntu/.local/bin/Student.py 2>/dev/null || true
    chmod 755 /home/ubuntu/.local/bin/Student.py 2>/dev/null || true
fi
